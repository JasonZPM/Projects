/*
 * 任务完成，收藏人，等操作时，判断是否活得荣誉，如果获得的话，则通知获得者获得徽章
 * 引用该文件是，放在key,api 的js文件引用后面
 * 
 * 说明：
 * type：
 * 1.查询Honor_ptask 发布任务完成数
 * 2.查找Honor_ftask 接收任务完成数
 * 3.查找Honor_gtask 活动五星好评数
 * 4.查找Honor_psquare 发布广场数
 * 5.收藏人
 * 6.收藏任务
 * 7.收藏广场
 */
client = new Resource(KEY.appId, KEY.appKey);
User = client.Factory("user");
function IFGetHonor(userid,type){
	var field=new Array;
	if(type==1){//field[0]
		field=["Honor_ptask"];
	}else if(type==2){
		field=["Honor_ftask"];
	}else if(type==3){
		field=["Honor_gtask"];
	}else if(type==4){
		field=["Honor_psquare"];
	}else if(type==5){
		field=["collection_user_id"];
	}else if(type==6){
		field=["collection_task_id"];
	}else if(type==7){
		field=["collection_square_id"];
	}

	var filter={
		"where":{'id':userid},
		"fields":field
		};
	User.query({filter:filter}, function(ret,err){
		if(ret){
			if(type==1){//field[0]
				var temp=ret[0].Honor_ptask+1;
				SAVE(userid,1,temp);
				if(temp==30){
				giveHonor(3);
				MessageGetHonor(userid,HONOR[3].url);
				return;
				}else if(temp==20){
				giveHonor(2);
				MessageGetHonor(userid,HONOR[2].url);
				return;
				}else if(temp==10){
				giveHonor(1);
				MessageGetHonor(userid,HONOR[1].url);
				return;
				}
			}else if(type==2){
				var temp=ret[0].Honor_ftask+1;
				SAVE(userid,2,temp);
				if(temp==30){
				giveHonor(6);
				MessageGetHonor(userid,HONOR[6].url);
				return;
				}else if(temp==20){
				giveHonor(5);
				MessageGetHonor(userid,HONOR[5].url);
				return;
				}else if(temp==10){
				giveHonor(4);
				MessageGetHonor(userid,HONOR[4].url);
				return;
				}
			}else if(type==3){
				var temp=ret[0].Honor_gtask+1;
				SAVE(userid,3,temp);
				if(temp==30){
				giveHonor(9);
				MessageGetHonor(userid,HONOR[9].url);
				return;
				}else if(temp==20){
				giveHonor(8);
				MessageGetHonor(userid,HONOR[8].url);
				return;
				}else if(temp==10){
				giveHonor(7);
				MessageGetHonor(userid,HONOR[7].url);
				return;
				}
			}else if(type==4){
				var temp=ret[0].Honor_psquare+1;
				SAVE(userid,4,temp);
				if(temp==30){
				giveHonor(12);
				MessageGetHonor(userid,HONOR[12].url);
				return;
				}else if(temp==20){
				giveHonor(11);
				MessageGetHonor(userid,HONOR[11].url);
				return;
				}else if(temp==10){
				giveHonor(10);
				MessageGetHonor(userid,HONOR[10].url);
				return;
				}
			}else if(type==5){//收藏人
				var temp=ret[0].collection_user_id.length;
				if(temp==20){
				giveHonor(14);
				MessageGetHonor(userid,HONOR[14].url);
				return;
				}else if(temp==10){
				giveHonor(13);
				MessageGetHonor(userid,HONOR[13].url);
				return;
				}
			}else if(type==6){//收藏任务
				var temp=ret[0].collection_task_id.length;
				if(temp==20){
				giveHonor(16);
				MessageGetHonor(userid,HONOR[16].url);
				return;
				}else if(temp==10){
				giveHonor(15);
				MessageGetHonor(userid,HONOR[15].url);
				return;
				}
			}else if(type==7){//收藏广场
				var temp=ret[0].collection_square_id.length;
				if(temp==20){
				giveHonor(18);
				MessageGetHonor(userid,HONOR[18].url);
				return;
				}else if(temp==10){
				giveHonor(17);
				MessageGetHonor(userid,HONOR[17].url);
				return;
				}
			}
		}else{
			toast.fail({
			    title:"请求超时",
			    duration:2000
			});
			return false;
		}
	});
	return true;
}

function MessageGetHonor(userid,honorurl){
	var model = api.require('model');
	model.config({
	    appKey: KEY.appKey,
	    host: KEY.apphost
	});
	var relation = api.require('relation');
	relation.insert({
	    class:'user',//有relation字段的表名
	    id: userid,//id
	    column:'mymessage',//relation字段
	    value: {//关联表的key:value，即student表的key:value
	        title:'获得徽章',
	        username:'系统消息',
	        userheadimg:honorurl,
	        to_user:userid,
	        statue:0,
	        type:5,
	    }
	}, function(ret2, err2){
	     if( ret2 ){
	     }else{
	     	toast.fail({
			    title:"请求超时",
			    duration:2000
			});
			return false;
	     }
	});
}
//,"$push": { honor: -2}
function SAVE(userid,type,saveWhat){
		if(type==1){//field[0]
			User.save({"_id":userid},{"Honor_ptask":saveWhat}, function(ret3,err3){
			    if(ret3){
			    }else{
			        toast.fail({
					    title:"请求超时",
					    duration:2000
					});
					return false;
			    }
			})
		}else if(type==2){
			User.save({"_id":userid},{"Honor_ftask":saveWhat}, function(ret3,err3){
			    if(ret3){
			    }else{
			        toast.fail({
					    title:"请求超时",
					    duration:2000
					});
					return false;
			    }
			})
		}else if(type==3){
			User.save({"_id":userid},{ "Honor_gtask":saveWhat}, function(ret3,err3){
			    if(ret3){
			    }else{
			        toast.fail({
					    title:"请求超时",
					    duration:2000
					});
					return false;
			    }
			})
		}else if(type==4){
			User.save({"_id":userid},{ "Honor_psquare":saveWhat}, function(ret3,err3){
			    if(ret3){
			    }else{
			        toast.fail({
					    title:"请求超时",
					    duration:2000
					});
					return false;
			    }
			})
		}else if(type==5){
			//无
		}else if(type==6){
			//无
		}else if(type==7){
			//无
		}
}

function giveHonor(honorid){
	User.save({"_id":userid},{ "$push": { honor: honorid}}, function(ret3,err3){
	    if(ret3){
	    }else{
	        toast.fail({
			    title:"请求超时",
			    duration:2000
			});
			return false;
	    }
	})
}